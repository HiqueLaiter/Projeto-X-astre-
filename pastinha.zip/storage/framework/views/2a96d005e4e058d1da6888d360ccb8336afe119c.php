<h1>Oi xastre</h1>
<img src="/img/ricardo.png" alt="banner">
<a href="/">voltar</a><?php /**PATH C:\Users\22008543\example-app\resources\views/Xastre.blade.php ENDPATH**/ ?>